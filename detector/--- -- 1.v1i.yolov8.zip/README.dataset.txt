# ПАК дз 1 > 2024-02-12 10:12am
https://universe.roboflow.com/project-ennic/-1-acin6

Provided by a Roboflow user
License: Public Domain

